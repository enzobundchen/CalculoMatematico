package viewMenu;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;

public class menu extends JFrame{
	
	private JButton btnDescPerc,btnSomaPerc, btnPercdeY, btnXdeY,
	btnDesc, btnDifPerc, btnValorOrg, btnRegra3, btnGerSenha;
	private JPanel painelCalc, painelOp;
	private JLabel labelEscolha, labelDescPerc, labelSomaPerc, labelPercdeY, labelXdeY,
		labelDesc, labelDifPerc, labelValorOrg, labelRegra3, labelGerSenha;
	
	public menu() {
		setSize(535, 760);
		setLocationRelativeTo(null);
		setTitle("Calculos Matematicos");
		setLayout(null);
		setResizable(true); // Maximizar ou minimizar;
		setDefaultCloseOperation(EXIT_ON_CLOSE); // Isso vai fazer o programa fechar quando apertar no "X";
		CriarComponentes();
		setVisible(true);
	}
	
	public void CriarComponentes() {
		Border borda = BorderFactory.createLineBorder(Color.black, 3);
		Border bordainf = BorderFactory.createMatteBorder(0, 0, 2, 0, Color.black);
		
		// Painel Principal;
		painelCalc = new JPanel();
		painelCalc.setBounds(10, 10, 500, 700);
		painelCalc.setBackground(Color.LIGHT_GRAY);
		getContentPane().add(painelCalc);
		painelCalc.setLayout(null);
		painelCalc.setBorder(borda);
		
		// Título; 
		labelEscolha = new JLabel("Escolha a operação matemática que deseja realizar");
		labelEscolha.setForeground(Color.black);
		labelEscolha.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
		labelEscolha.setBorder(bordainf);
		painelCalc.add(labelEscolha);
		labelEscolha.setBounds(60, 10, 390, 30);
		
		// 1° botão;
		painelOp = new JPanel();
		painelOp.setBounds(120, 70, 260, 50);
		painelOp.setBackground(Color.GRAY);
		painelCalc.add(painelOp);
		painelOp.setBorder(borda);
		
		btnDescPerc = new JButton(new AbstractAction("Aplicar desconto % num valor") {
			
			public void actionPerformed(ActionEvent e) {
				aplicarDesconto aplicarDesconto = new aplicarDesconto();
				aplicarDesconto.setVisible(true);
				
			}
		});
		
		btnDescPerc.setForeground(Color.black);
		btnDescPerc.setBackground(Color.GRAY);
		btnDescPerc.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
		btnDescPerc.setFocusPainted(false);
		btnDescPerc.setBorderPainted(false);
		painelOp.add(btnDescPerc);
		btnDescPerc.setBounds(0, 80, 30, 30);
		
		// 2° botão;
		painelOp = new JPanel();
		painelOp.setBounds(120, 140, 260, 50);
		painelOp.setBackground(Color.GRAY);
		painelCalc.add(painelOp);
		painelOp.setBorder(borda);
		
		btnSomaPerc = new JButton(new AbstractAction("Incrementar % a um valor") {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Incrementar Incrementar = new Incrementar();
				Incrementar.setVisible(true);
				
			}
		} );
		btnSomaPerc.setForeground(Color.black);
		btnSomaPerc.setBackground(Color.GRAY);
		btnSomaPerc.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
		btnSomaPerc.setFocusPainted(false);
		btnSomaPerc.setBorderPainted(false);
		painelOp.add(btnSomaPerc);
		btnSomaPerc.setBounds(0, 80, 30, 30);
		
		// 3° botão;
		painelOp = new JPanel();
		painelOp.setBounds(120, 210, 260, 50);
		painelOp.setBackground(Color.GRAY);
		painelCalc.add(painelOp);
		painelOp.setBorder(borda);
		
		btnPercdeY = new JButton(new AbstractAction("Quanto X % representa de Y") {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				quantoPercXdeY QuantoPercXdeY = new quantoPercXdeY();
				QuantoPercXdeY.setVisible(true);
			}
		});
		btnPercdeY.setForeground(Color.black);
		btnPercdeY.setBackground(Color.GRAY);
		btnPercdeY.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
		btnPercdeY.setFocusPainted(false);
		btnPercdeY.setBorderPainted(false);
		painelOp.add(btnPercdeY);
		btnPercdeY.setBounds(0, 80, 30, 30);
		
		// 4° botão;
		painelOp = new JPanel();
		painelOp.setBounds(120, 280, 260, 50);
		painelOp.setBackground(Color.GRAY);
		painelCalc.add(painelOp);
		painelOp.setBorder(borda);
				
		btnXdeY = new JButton(new AbstractAction("Quanto X representa de Y") {
			
			public void actionPerformed(ActionEvent e) {
				quantoXdeY quantoXdeY = new quantoXdeY();
				quantoXdeY.setVisible(true);
			}
		});
		
		btnXdeY.setForeground(Color.black);
		btnXdeY.setBackground(Color.GRAY);
		btnXdeY.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
		btnXdeY.setFocusPainted(false);
		btnXdeY.setBorderPainted(false);
		painelOp.add(btnXdeY);
		btnXdeY.setBounds(0, 80, 30, 30);
		
		// 5° botão;
		painelOp = new JPanel();
		painelOp.setBounds(120, 350, 260, 50);
		painelOp.setBackground(Color.GRAY);
		painelCalc.add(painelOp);
		painelOp.setBorder(borda);
		
		btnDesc = new JButton(new AbstractAction("Qual foi o desconto %?") {
			
			public void actionPerformed(ActionEvent e) {
				quantoDesconto quantoDesconto = new quantoDesconto();
				quantoDesconto.setVisible(true);
				
			}
		});

		btnDesc.setForeground(Color.black);
		btnDesc.setBackground(Color.GRAY);
		btnDesc.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
		btnDesc.setFocusPainted(false);
		btnDesc.setBorderPainted(false);
		painelOp.add(btnDesc);
		
		// 6° botão;
		painelOp = new JPanel();
		painelOp.setBounds(120, 420, 260, 50);
		painelOp.setBackground(Color.GRAY);
		painelCalc.add(painelOp);
		painelOp.setBorder(borda);
								
		btnDifPerc = new JButton(new AbstractAction("Diferença entre valores") {
			
			public void actionPerformed(ActionEvent e) {
				variacaoPercentual variacaoPercentual = new variacaoPercentual();
				variacaoPercentual.setVisible(true);
			}
		});
				
		btnDifPerc.setForeground(Color.black);
		btnDifPerc.setBackground(Color.GRAY);
		btnDifPerc.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
		btnDifPerc.setFocusPainted(false);
		btnDifPerc.setBorderPainted(false);
		painelOp.add(btnDifPerc);
		btnDifPerc.setBounds(0, 80, 30, 30);
		
		// 7° botão;
		painelOp = new JPanel();
		painelOp.setBounds(120, 490, 260, 50);
		painelOp.setBackground(Color.GRAY);
		painelCalc.add(painelOp);
		painelOp.setBorder(borda);

		btnValorOrg = new JButton(new AbstractAction("Qual era o valor original?") {
					
			public void actionPerformed(ActionEvent e) {
				valorOriginalComDesconto valorOriginalComDesconto = new valorOriginalComDesconto();
				valorOriginalComDesconto.setVisible(true);
			}
		});
		
		btnValorOrg.setForeground(Color.black);
		btnValorOrg.setBackground(Color.GRAY);
		btnValorOrg.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
		btnValorOrg.setFocusPainted(false);
		btnValorOrg.setBorderPainted(false);
		painelOp.add(btnValorOrg);
		btnValorOrg.setBounds(0, 80, 30, 30);
		
		// 8° botão;
		painelOp = new JPanel();
		painelOp.setBounds(120, 560, 260, 50);
		painelOp.setBackground(Color.GRAY);
		painelCalc.add(painelOp);
		painelOp.setBorder(borda);
								
		btnRegra3 = new JButton(new AbstractAction("Regra de Três") {
			
			public void actionPerformed(ActionEvent e) {
				RegraDeTres RegraDeTres = new RegraDeTres();
				RegraDeTres.setVisible(true);
			}
		});
		
		btnRegra3.setForeground(Color.black);
		btnRegra3.setBackground(Color.GRAY);
		btnRegra3.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
		btnRegra3.setFocusPainted(false);
		btnRegra3.setBorderPainted(false);
		painelOp.add(btnRegra3);
		btnRegra3.setBounds(0, 80, 30, 30);
		
		// 9° botão
		painelOp = new JPanel();
		painelOp.setBounds(120, 630, 260, 50);
		painelOp.setBackground(Color.GRAY);
		painelCalc.add(painelOp);
		painelOp.setBorder(borda);
		
		btnGerSenha = new JButton(new AbstractAction("Gerador de senha") {
			
			public void actionPerformed(ActionEvent e) {
				GeradorDeSenha GeradorDeSenha = new GeradorDeSenha();
				GeradorDeSenha.setVisible(true);
				
			}
		});
										
		btnGerSenha.setForeground(Color.black);
		btnGerSenha.setBackground(Color.GRAY);
		btnGerSenha.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
		btnGerSenha.setFocusPainted(false);
		btnGerSenha.setBorderPainted(false);
		painelOp.add(btnGerSenha);
		btnGerSenha.setBounds(0, 80, 30,30);
		
	}
	
}