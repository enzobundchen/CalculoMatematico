package viewMenu;

import java.awt.Color;
import java.awt.event.ActionEvent;
import javax.swing.*;

public class valorOriginalComDesconto extends JFrame {

	private JLabel lblValorFinal, lblDesconto, lblValorOriginal;
	private JTextField txfValorFinal, txfDesconto, txfValorOriginal;
	private JButton btnCalcular;

	public valorOriginalComDesconto() {
		setSize(345, 200);
		setLocationRelativeTo(null);
		setTitle("Valor original com desconto");
		setLayout(null);
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		componentesCriar();
		setVisible(true);
	}

	private void componentesCriar() {
		lblValorFinal = new JLabel("Valor final R$ (a)");
		lblValorFinal.setBounds(32, 10, 120, 25);
		lblValorFinal.setForeground(Color.red);
		getContentPane().add(lblValorFinal);

		txfValorFinal = new JTextField();
		txfValorFinal.setBounds(135, 10, 150, 25);
		txfValorFinal.setBackground(Color.decode("#ffe7e7"));
		getContentPane().add(txfValorFinal);

		lblDesconto = new JLabel("% desconto (b)");
		lblDesconto.setBounds(40, 40, 120, 25);
		lblDesconto.setForeground(Color.blue);
		getContentPane().add(lblDesconto);

		txfDesconto = new JTextField();
		txfDesconto.setBounds(135, 40, 150, 25);
		txfDesconto.setBackground(Color.decode("#e7feff"));
		getContentPane().add(txfDesconto);

		JLabel lblPct = new JLabel("%");
		lblPct.setBounds(290, 40, 25, 25);
		lblPct.setForeground(Color.blue);
		getContentPane().add(lblPct);

		lblValorOriginal = new JLabel("Valor inicial");
		lblValorOriginal.setBounds(56, 70, 120, 25);
		getContentPane().add(lblValorOriginal);

		txfValorOriginal = new JTextField();
		txfValorOriginal.setBounds(135, 70, 150, 25);
		getContentPane().add(txfValorOriginal);

		btnCalcular = new JButton(new AbstractAction("Calcular") {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (txfValorFinal.getText().isEmpty() || txfDesconto.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos");
					return;
				}

				double a = Double.parseDouble(txfValorFinal.getText());
				double b = Double.parseDouble(txfDesconto.getText());

				if (b >= 100) {
					JOptionPane.showMessageDialog(null, "Desconto inválido");
					return;
				}

				double resultado = (a * 100) / (100 - b);
				txfValorOriginal.setText(String.format("%.2f", resultado));
			}
		});
		btnCalcular.setBounds(10, 110, 310, 40);
		getContentPane().add(btnCalcular);
	}

	public static void main(String[] args) {
		new valorOriginalComDesconto();
	}
}
