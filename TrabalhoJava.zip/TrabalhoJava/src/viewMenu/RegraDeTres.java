package viewMenu;

import java.awt.Color;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class RegraDeTres extends JFrame {

    private JLabel Title,lblA, lblB, lblR1, lblR2;
    private JTextField txfA, txfB, txfR1, txfR2;
    private JButton btnCalcular;

    public RegraDeTres() {
        setSize(345, 180);
        setLocationRelativeTo(null);
        setTitle("Regra de Três");
        setLayout(null);
        setResizable(false);
        componentesCriar();
        setVisible(true);
    }

    private void componentesCriar() {
    	
        lblA = new JLabel("a:");
        lblA.setBounds(25, 15, 50, 25);
        lblA.setForeground(Color.RED);
        getContentPane().add(lblA);

        txfA = new JTextField();
        txfA.setBounds(50, 15, 100, 25);
        txfA.setBackground(Color.decode("#ffe7e7"));
        getContentPane().add(txfA);

        lblR1 = new JLabel("=  r1:");
        lblR1.setBounds(160, 15, 50, 25);
        lblR1.setForeground(new Color(0, 128, 0));
        getContentPane().add(lblR1);

        txfR1 = new JTextField();
        txfR1.setBounds(200, 15, 100, 25);
        txfR1.setBackground(Color.decode("#e7ffeb"));
        getContentPane().add(txfR1);

        lblB = new JLabel("b:");
        lblB.setBounds(25, 50, 50, 25);
        lblB.setForeground(Color.BLUE);
        getContentPane().add(lblB);

        txfB = new JTextField();
        txfB.setBounds(50, 50, 100, 25);
        txfB.setBackground(Color.decode("#e7feff"));
        getContentPane().add(txfB);

        lblR2 = new JLabel("=  r2:");
        lblR2.setBounds(160, 50, 50, 25);
        getContentPane().add(lblR2);

        txfR2 = new JTextField();
        txfR2.setBounds(200, 50, 100, 25);
        txfR2.setEditable(false);
        getContentPane().add(txfR2);

        btnCalcular = new JButton(new AbstractAction("Calcular") {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    double a = Double.parseDouble(txfA.getText());
                    double b = Double.parseDouble(txfB.getText());
                    double r1 = Double.parseDouble(txfR1.getText());

                    if (a == 0) {
                        JOptionPane.showMessageDialog(null, "Valor de 'a' não pode ser zero");
                        return;
                    }

                    double r2 = (r1 * b) / a;
                    txfR2.setText(String.format("%.2f", r2));
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Preencha todos os campos corretamente");
                }
            }
        });
        btnCalcular.setBounds(10, 90, 310, 40);
        getContentPane().add(btnCalcular);
    }

    public static void main(String[] args) {
        new RegraDeTres();
    }
}
