package viewMenu;

import java.awt.Color;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class aplicarDesconto extends JFrame{
	
	private JLabel lblSubTittle, lblVlrInicial,lblDesconto,lblResultado;
	private JTextField txfVlrInicial, txfDesconto, txfResultado;
	private JButton btnSalvar;

	public aplicarDesconto() {
		setSize(345, 200);
		setLocationRelativeTo(null);
		setTitle("Aplicar desconto % num valor");
		setLayout(null);
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		componentesCriar();
		setVisible(true);
	}
	
	private void componentesCriar() {

		lblVlrInicial = new JLabel("Valor inicial R$ (a)");
		lblVlrInicial.setBounds(20, 10, 120, 25);
		lblVlrInicial.setForeground(Color.red);
		getContentPane().add(lblVlrInicial);
		
		txfVlrInicial = new JTextField();
		txfVlrInicial.setBounds(135, 13, 150, 25);
		txfVlrInicial.setBackground(Color.decode("#ffe7e7"));
		getContentPane().add(txfVlrInicial);
		
		lblDesconto = new JLabel("% Desconto (b)");
		lblDesconto.setBounds(36, 40, 120, 25);
		lblDesconto.setForeground(Color.blue);
		getContentPane().add(lblDesconto);
		
		lblDesconto = new JLabel("%");
		lblDesconto.setBounds(290, 43, 50, 25);
		lblDesconto.setForeground(Color.blue);
		getContentPane().add(lblDesconto);
		
		txfDesconto = new JTextField();
		txfDesconto.setBounds(135, 43, 150, 25);
		txfDesconto.setBackground(Color.decode("#e7feff"));
		getContentPane().add(txfDesconto);
		
		lblResultado = new JLabel("Resultado");
		lblResultado.setBounds(64, 70, 120, 25);
		getContentPane().add(lblResultado);
		
		txfResultado = new JTextField();
		txfResultado.setBounds(135, 73, 150, 25);
		getContentPane().add(txfResultado);
		
		btnSalvar = new JButton(new AbstractAction("Calcular") {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(txfVlrInicial.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Campo 'Valor inicial' Obrigatório");
					txfVlrInicial.requestFocus();
				    return;
				}
				if(txfDesconto.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Campo '% Desconto' Obrigatório");
					txfDesconto.requestFocus();
				    return;
				}
				
				double valorInicial = Double.parseDouble(txfVlrInicial.getText());
				double valorDesconto = Double.parseDouble(txfDesconto.getText());
				
				double resultado = valorInicial - (valorInicial *(valorDesconto / 100));
				
				txfResultado.setText(String.valueOf(resultado));
				
			}
		});
		btnSalvar.setBounds(10, 110, 310, 40);
		getContentPane().add(btnSalvar);
		}
	
	public static void main(String[] args) {
	    new aplicarDesconto();
	}
}