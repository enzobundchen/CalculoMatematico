package viewMenu;

import java.awt.Color;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class quantoXdeY extends JFrame {

    private JLabel lblSubTittle, lblParte, lblTotal, lblResultado;
    private JTextField txfParte, txfTotal, txfResultado;
    private JButton btnCalcular;

    public quantoXdeY() {
        setSize(345, 200);
        setLocationRelativeTo(null);
        setTitle("Quanto X representa de Y");
        setLayout(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        componentesCriar();
        setVisible(true);
    }

    private void componentesCriar() {
        lblTotal = new JLabel("Total (a)");
        lblTotal.setBounds(83, 10, 120, 25);
        lblTotal.setForeground(Color.red);
        getContentPane().add(lblTotal);

        txfTotal = new JTextField();
        txfTotal.setBounds(135, 10, 150, 25);
        txfTotal.setBackground(Color.decode("#ffe7e7"));
        getContentPane().add(txfTotal);

        lblParte = new JLabel("Parte (b)");
        lblParte.setBounds(80, 40, 120, 25);
        lblParte.setForeground(Color.blue);
        getContentPane().add(lblParte);

        txfParte = new JTextField();
        txfParte.setBounds(135, 40, 150, 25);
        txfParte.setBackground(Color.decode("#e7feff"));
        getContentPane().add(txfParte);

        lblResultado = new JLabel("Corresponde a %");
        lblResultado.setBounds(32, 70, 120, 25);
        getContentPane().add(lblResultado);

        txfResultado = new JTextField();
        txfResultado.setBounds(135, 70, 150, 25);
        getContentPane().add(txfResultado);

        JLabel lblPercent = new JLabel("%");
        lblPercent.setBounds(290, 70, 50, 25);
        lblPercent.setForeground(Color.black);
        getContentPane().add(lblPercent);

        btnCalcular = new JButton(new AbstractAction("Calcular") {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (txfTotal.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Campo 'Total' Obrigatório");
                    txfTotal.requestFocus();
                    return;
                }
                if (txfParte.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Campo 'Parte' Obrigatório");
                    txfParte.requestFocus();
                    return;
                }

                double valorTotal = Double.parseDouble(txfTotal.getText());
                double valorParte = Double.parseDouble(txfParte.getText());

                if (valorTotal == 0) {
                    JOptionPane.showMessageDialog(null, "O valor total não pode ser zero.");
                    return;
                }

                double resultado = (valorParte / valorTotal) * 100;
                txfResultado.setText(String.format("%.2f", resultado));
            }
        });
        btnCalcular.setBounds(10, 110, 310, 40);
        getContentPane().add(btnCalcular);
    }

    public static void main(String[] args) {
        new quantoXdeY();
    }
}
