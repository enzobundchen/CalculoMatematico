package viewMenu;

import java.awt.Color;
import java.awt.event.ActionEvent;
import javax.swing.*;

public class variacaoPercentual extends JFrame {

	private JLabel lblValorInicial, lblValorFinal, lblResultado;
	private JTextField txfValorInicial, txfValorFinal, txfResultado;
	private JButton btnCalcular;

	public variacaoPercentual() {
		setSize(345, 200);
		setLocationRelativeTo(null);
		setTitle("Diferença % entre valores");
		setLayout(null);
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		componentesCriar();
		setVisible(true);
	}

	private void componentesCriar() {
		lblValorInicial = new JLabel("Valor inicial (a)");
		lblValorInicial.setBounds(40, 10, 120, 25);
		lblValorInicial.setForeground(Color.red);
		getContentPane().add(lblValorInicial);

		txfValorInicial = new JTextField();
		txfValorInicial.setBounds(135, 10, 150, 25);
		txfValorInicial.setBackground(Color.decode("#ffe7e7"));
		getContentPane().add(txfValorInicial);

		lblValorFinal = new JLabel("Valor final (b)");
		lblValorFinal.setBounds(48, 40, 120, 25);
		lblValorFinal.setForeground(Color.blue);
		getContentPane().add(lblValorFinal);

		txfValorFinal = new JTextField();
		txfValorFinal.setBounds(135, 40, 150, 25);
		txfValorFinal.setBackground(Color.decode("#e7feff"));
		getContentPane().add(txfValorFinal);

		lblResultado = new JLabel("Diferença %");
		lblResultado.setBounds(55, 70, 120, 25);
		getContentPane().add(lblResultado);

		txfResultado = new JTextField();
		txfResultado.setBounds(135, 70, 150, 25);
		getContentPane().add(txfResultado);

		JLabel lblPorcento = new JLabel("%");
		lblPorcento.setBounds(290, 70, 25, 25);
		getContentPane().add(lblPorcento);

		btnCalcular = new JButton(new AbstractAction("Calcular") {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (txfValorInicial.getText().isEmpty() || txfValorFinal.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos");
					return;
				}

				double a = Double.parseDouble(txfValorInicial.getText());
				double b = Double.parseDouble(txfValorFinal.getText());

				double resultado = ((b - a) / a) * 100;
				txfResultado.setText(String.format("%.2f", resultado));
			}
		});
		btnCalcular.setBounds(10, 110, 310, 40);
		getContentPane().add(btnCalcular);
	}

	public static void main(String[] args) {
		new variacaoPercentual();
	}
}
