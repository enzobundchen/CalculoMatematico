package viewMenu;

import java.awt.Color;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class quantoPercXdeY extends JFrame{
	
	private JLabel lblSubTittle, lblPorcentagem,lblTotal,lblResultado;
	private JTextField txfPorcentagem, txfTotal, txfResultado;
	private JButton btnSalvar;

	public quantoPercXdeY() {
		setSize(345, 200);
		setLocationRelativeTo(null);
		setTitle("Quanto X % representa de Y");
		setLayout(null);
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		componentesCriar();
		setVisible(true);
	}
	
	private void componentesCriar() {

		lblTotal = new JLabel("Total (a)");
		lblTotal.setBounds(80, 10, 120, 25);
		lblTotal.setForeground(Color.red);
		getContentPane().add(lblTotal);
		
		txfTotal = new JTextField();
		txfTotal.setBounds(135, 10, 150, 25);
		txfTotal.setBackground(Color.decode("#ffe7e7"));
		getContentPane().add(txfTotal);
		
		lblPorcentagem = new JLabel("Porcentagem (b)");
		lblPorcentagem.setBounds(30, 40, 120, 25);
		lblPorcentagem.setForeground(Color.blue);
		getContentPane().add(lblPorcentagem);
		
		lblPorcentagem = new JLabel("%");
		lblPorcentagem.setBounds(290, 40, 50, 25);
		lblPorcentagem.setForeground(Color.blue);
		getContentPane().add(lblPorcentagem);
		
		txfPorcentagem = new JTextField();
		txfPorcentagem.setBounds(135, 40, 150, 25);
		txfPorcentagem.setBackground(Color.decode("#e7feff"));
		getContentPane().add(txfPorcentagem);
		
		lblResultado = new JLabel("Corresponde a");
		lblResultado.setBounds(40, 70, 120, 25);
		getContentPane().add(lblResultado);
		
		txfResultado = new JTextField();
		txfResultado.setBounds(135, 70, 150, 25);
		getContentPane().add(txfResultado);
		
		btnSalvar = new JButton(new AbstractAction("Calcular") {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(txfTotal.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Campo 'Total' Obrigatório");
					txfTotal.requestFocus();
				    return;
				}
				if(txfPorcentagem.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Campo 'Porcentagem' Obrigatório");
					txfPorcentagem.requestFocus();
				    return;
				}
				
				double valorTotal = Double.parseDouble(txfTotal.getText());
				double valorPorcentagem = Double.parseDouble(txfPorcentagem.getText());
				
				double resultado = (valorTotal * valorPorcentagem) / 100;
				
				txfResultado.setText(String.valueOf(resultado));
				
			}
		});
		btnSalvar.setBounds(10, 110, 310, 40);
		getContentPane().add(btnSalvar);
		}
	
	public static void main(String[] args) {
	    new quantoPercXdeY();
	}
}