package viewMenu;

import java.awt.Color;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Incrementar extends JFrame{
	
	private JLabel lblSubTittle, lblVlrInicial,lblAcrescimo,lblResultado;
	private JTextField txfVlrInicial, txfAcrescimo, txfResultado;
	private JButton btnSalvar;

	public Incrementar() {
		setSize(345, 200);
		setLocationRelativeTo(null);
		setTitle("Incrementar % a um valor");
		setLayout(null);
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		componentesCriar();
		setVisible(true);
	}
	
	private void componentesCriar() {
		
		lblVlrInicial = new JLabel("Valor inicial R$ (a)");
		lblVlrInicial.setBounds(20, 10, 120, 25);
		lblVlrInicial.setForeground(Color.red);
		getContentPane().add(lblVlrInicial);
		
		txfVlrInicial = new JTextField();
		txfVlrInicial.setBounds(135, 13, 150, 25);
		txfVlrInicial.setBackground(Color.decode("#ffe7e7"));
		getContentPane().add(txfVlrInicial);
		
		lblAcrescimo = new JLabel("% Acréscimo (b)");
		lblAcrescimo.setBounds(30, 40, 120, 25);
		lblAcrescimo.setForeground(Color.blue);
		getContentPane().add(lblAcrescimo);
		
		lblAcrescimo = new JLabel("%");
		lblAcrescimo.setBounds(290, 43, 50, 25);
		lblAcrescimo.setForeground(Color.blue);
		getContentPane().add(lblAcrescimo);
		
		txfAcrescimo = new JTextField();
		txfAcrescimo.setBounds(135, 43, 150, 25);
		txfAcrescimo.setBackground(Color.decode("#e7feff"));
		getContentPane().add(txfAcrescimo);
		
		lblResultado = new JLabel("Resultado");
		lblResultado.setBounds(63, 70, 120, 25);
		getContentPane().add(lblResultado);
		
		txfResultado = new JTextField();
		txfResultado.setBounds(135, 73, 150, 25);
		getContentPane().add(txfResultado);
		
		btnSalvar = new JButton(new AbstractAction("Calcular") {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(txfVlrInicial.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Campo 'Valor inicial' Obrigatório");
					txfVlrInicial.requestFocus();
				    return;
				}
				if(txfAcrescimo.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Campo '% Acréscimo' Obrigatório");
					txfAcrescimo.requestFocus();
				    return;
				}
				
				double valorInicial = Double.parseDouble(txfVlrInicial.getText());
				double valorAcrescimo = Double.parseDouble(txfAcrescimo.getText());
				
				double resultado = valorInicial + (valorInicial *(valorAcrescimo / 100));
				
				txfResultado.setText(String.valueOf(resultado));
				
			}
		});
		btnSalvar.setBounds(10, 110, 310, 40);
		getContentPane().add(btnSalvar);
		}
	
	public static void main(String[] args) {
	    new Incrementar();
	}
}