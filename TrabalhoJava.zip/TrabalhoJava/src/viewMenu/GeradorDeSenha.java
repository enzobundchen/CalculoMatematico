package viewMenu;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.security.SecureRandom;

public class GeradorDeSenha extends JFrame {

    private JCheckBox chkMaiusculas, chkMinusculas, chkNumeros, chkSimbolos;
    private JSpinner spinnerTamanho;
    private JTextField txtSenhaGerada;
    private JButton btnGerar;

    public GeradorDeSenha() {
        setTitle("Gerador de Senha");
        setSize(345, 220);
        setLocationRelativeTo(null);
        setLayout(null);
        setResizable(false);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        componentesCriar();
        setVisible(true);
    }

    private void componentesCriar() {
    	
        chkMaiusculas = new JCheckBox("Maiúsculas", true);
        chkMaiusculas.setBounds(20, 20, 120, 25);
        getContentPane().add(chkMaiusculas);

        chkMinusculas = new JCheckBox("Minúsculas", true);
        chkMinusculas.setBounds(180, 20, 120, 25);
        getContentPane().add(chkMinusculas);

        chkNumeros = new JCheckBox("Números", true);
        chkNumeros.setBounds(20, 50, 120, 25);
        getContentPane().add(chkNumeros);

        chkSimbolos = new JCheckBox("Símbolos", true);
        chkSimbolos.setBounds(180, 50, 120, 25);
        getContentPane().add(chkSimbolos);

        JLabel lblTamanho = new JLabel("Tamanho:");
        lblTamanho.setBounds(25, 90, 70, 25);
        getContentPane().add(lblTamanho);

        spinnerTamanho = new JSpinner(new SpinnerNumberModel(8, 4, 32, 1));
        spinnerTamanho.setBounds(90, 90, 50, 25);
        getContentPane().add(spinnerTamanho);

        btnGerar = new JButton("Gerar");
        btnGerar.setBounds(183, 90, 100, 25);
        getContentPane().add(btnGerar);

        txtSenhaGerada = new JTextField();
        txtSenhaGerada.setBounds(20, 135, 287, 30);
        txtSenhaGerada.setEditable(false);
        txtSenhaGerada.setForeground(Color.BLACK);
        txtSenhaGerada.setCaretColor(Color.BLACK);
        getContentPane().add(txtSenhaGerada);

        btnGerar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int tamanho = (int) spinnerTamanho.getValue();
                String senha = gerarSenha(tamanho);
                txtSenhaGerada.setText(senha);
            }
        });
    }

    private String gerarSenha(int tamanho) {
        String maiusculas = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String minusculas = "abcdefghijklmnopqrstuvwxyz";
        String numeros = "0123456789";
        String simbolos = "!@#$%&*_+-=?";

        StringBuilder conjunto = new StringBuilder();
        if (chkMaiusculas.isSelected()) conjunto.append(maiusculas);
        if (chkMinusculas.isSelected()) conjunto.append(minusculas);
        if (chkNumeros.isSelected()) conjunto.append(numeros);
        if (chkSimbolos.isSelected()) conjunto.append(simbolos);

        if (conjunto.length() == 0) {
            JOptionPane.showMessageDialog(this, "Selecione pelo menos uma opção", "Erro", JOptionPane.ERROR_MESSAGE);
            return "";
        }

        SecureRandom random = new SecureRandom();
        StringBuilder senha = new StringBuilder();

        for (int i = 0; i < tamanho; i++) {
            int index = random.nextInt(conjunto.length());
            senha.append(conjunto.charAt(index));
        }

        return senha.toString();
    }

    public static void main(String[] args) {
        new GeradorDeSenha();
    }
}
