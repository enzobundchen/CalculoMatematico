package viewMenu;

import java.awt.Color;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class quantoDesconto extends JFrame{
	
	private JLabel lblSubTittle, lblVlrOriginal,lblDesconto,lblResultado;
	private JTextField txfVlrOriginal, txfDesconto, txfResultado;
	private JButton btnSalvar;

	public quantoDesconto() {
		setSize(345, 200);
		setLocationRelativeTo(null);
		setTitle("Qual foi o desconto % ?");
		setLayout(null);
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		componentesCriar();
		setVisible(true);
	}
	
	private void componentesCriar() {

		lblVlrOriginal = new JLabel("Valor original (a)");
		lblVlrOriginal.setBounds(32, 10, 120, 25);
		lblVlrOriginal.setForeground(Color.red);
		getContentPane().add(lblVlrOriginal);
		
		txfVlrOriginal = new JTextField();
		txfVlrOriginal.setBounds(135, 10, 150, 25);
		txfVlrOriginal.setBackground(Color.decode("#ffe7e7"));
		getContentPane().add(txfVlrOriginal);
		
		lblDesconto = new JLabel("Valor c/ desconto(b)");
		lblDesconto.setBounds(10, 40, 120, 25);
		lblDesconto.setForeground(Color.blue);
		getContentPane().add(lblDesconto);
		
		txfDesconto = new JTextField();
		txfDesconto.setBounds(135, 40, 150, 25);
		txfDesconto.setBackground(Color.decode("#e7feff"));
		getContentPane().add(txfDesconto);
		
		lblResultado = new JLabel("% desconto");
		lblResultado.setBounds(58, 70, 120, 25);
		getContentPane().add(lblResultado);
		
		lblResultado = new JLabel("%");
		lblResultado.setBounds(290, 70, 50, 25);
		lblResultado.setForeground(Color.black);
		getContentPane().add(lblResultado);
		
		txfResultado = new JTextField();
		txfResultado.setBounds(135, 70, 150, 25);
		getContentPane().add(txfResultado);
		
		btnSalvar = new JButton(new AbstractAction("Calcular") {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(txfVlrOriginal.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Campo Valor inicial Obrigatório");
					txfVlrOriginal.requestFocus();
				    return;
				}
				if(txfDesconto.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Campo Desconto Obrigatório");
					txfDesconto.requestFocus();
				    return;
				}
				
				double valorInicial = Double.parseDouble(txfVlrOriginal.getText());
				double valorDesconto = Double.parseDouble(txfDesconto.getText());
				
				double resultado = ((valorInicial - valorDesconto)/valorInicial) * 100;
				
				txfResultado.setText(String.valueOf(resultado));
				
			}
		});
		btnSalvar.setBounds(10, 110, 310, 40);
		getContentPane().add(btnSalvar);
		}
	
	public static void main(String[] args) {
	    new quantoDesconto();
	}
}