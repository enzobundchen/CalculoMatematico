package main;

import viewMenu.menu;

public class mainMenu {

	public static void main(String[] args) {
		new menu();
	}
	
}
